import os
import requests

# Load environment variables
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    print("⚠️ Warning: 'dotenv' package is missing. Install it with 'pip install python-dotenv'.")

# API Key
API_KEY = os.getenv("GEMINI_API_KEY")
if not API_KEY:
    print("❌ Error: API key is missing! Set GEMINI_API_KEY in a .env file.")

# API URL
API_URL = f"https://generativelanguage.googleapis.com/v1/models/gemini-1.5-pro:generateContent?key={API_KEY}"

def get_response(user_input):
    """
    Function to send a request to Google Gemini AI and return the response.
    """
    if not API_KEY:
        return "❌ Error: API key is missing!"

    payload = {
        "contents": [{"parts": [{"text": user_input}]}]
    }
    headers = {"Content-Type": "application/json"}

    try:
        response = requests.post(API_URL, json=payload, headers=headers)
        response.raise_for_status()
        data = response.json()

        # Corrected response parsing
        candidates = data.get("candidates", [])
        if candidates:
            return candidates[0].get("content", {}).get("parts", [{}])[0].get("text", "No response received")
        return "🤖 Gemini AI: No response received."

    except requests.exceptions.RequestException as e:
        return f"❌ API Error: {str(e)}"

def chatbot():
    """
    Interactive chatbot loop.
    """
    print("\n🤖 Gemini AI Chatbot: Hello! Ask me anything or type 'exit' to quit.")

    while True:
        try:
            user_input = input("\nYou: ").strip()
            if user_input.lower() in ["bye", "exit", "quit"]:
                print("\n🤖 Gemini AI: Goodbye! 🚀")
                break

            response = get_response(user_input)
            print("\n🤖 Gemini AI:", response)
        except KeyboardInterrupt:
            print("\n\n🤖 Gemini AI: Goodbye! 🚀")
            break

if __name__ == "__main__":
    chatbot()
